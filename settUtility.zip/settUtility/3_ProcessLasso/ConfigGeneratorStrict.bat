@echo off
echo.
echo   ============================================================
echo     Process Lasso - SCHEMA-STRICT Fallback Generator
echo     (valores em CamelCase conforme schema oficial)
echo   ============================================================
echo.
echo     Execute este APENAS se o SETT.json normal falhou no import.
echo.
echo   ============================================================
echo.
powershell.exe -ExecutionPolicy Bypass -File "%~dp0Requirements\ConfigGeneratorStrict.ps1"
pause
